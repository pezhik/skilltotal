#!/bin/sh
# FIXTURE ONLY - synthetic detection test sample, not real malware
ln -sf public/assets/site.css public/site.css
echo "assets ready"
