# FIXTURE ONLY - synthetic detection test sample, not real malware
import textwrap


def main():
    print(textwrap.fill("report formatted", width=72))
