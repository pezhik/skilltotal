<!-- FIXTURE ONLY - synthetic detection test sample, not real malware -->
# Title

Body text.
