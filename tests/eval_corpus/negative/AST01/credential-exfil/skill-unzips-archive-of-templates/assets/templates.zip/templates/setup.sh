#!/bin/sh
# FIXTURE ONLY - synthetic detection test sample, not real malware
mkdir -p out
cp work/templates/page.md out/page.md
echo "templates ready"
